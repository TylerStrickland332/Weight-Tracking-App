import android.os.Bundle
import android.widget.Button
import android.widget.CalendarView
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.project3.GraphHelper
import com.example.project3.R
import com.example.project3.databinding.ActivityMain3Binding
import java.text.SimpleDateFormat
import java.util.*

class MainActivity3 : AppCompatActivity() {

    private lateinit var graphHelper: GraphHelper
    private lateinit var weight: String
    private lateinit var date: String
    private lateinit var binding: ActivityMain3Binding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMain3Binding.inflate(layoutInflater)
        setContentView(R.layout.activity_main3)

        graphHelper = GraphHelper(this)

        val weightEditText = findViewById<EditText>(R.id.insertWeight)

        val weightButton = findViewById<Button>(R.id.addWeight)
        val deleteButton = findViewById<Button>(R.id.deleteButton)

        weightButton.setOnClickListener {

            weight = weightEditText.text.toString()
            // Ensure date has been initialized before proceeding
            if (::date.isInitialized) {
                // Date is initialized, you can proceed with adding weight and date to the database
                // Call a function to add weight and date to the database
                addWeightAndDate(weight, date)
            } else {
                // Date is not initialized, handle this case as needed
                Toast.makeText(this, "Please select a date", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun formatDate(year: Int, month: Int, dayOfMonth: Int): String {
        val cal = Calendar.getInstance()
        cal.set(year, month, dayOfMonth)
        val dateFormat = SimpleDateFormat("MM-dd-yyyy", Locale.getDefault())
        return dateFormat.format(cal.time)
    }

    private fun addWeightAndDate(weight: String, date: String) {
        val dateExists = graphHelper.readDate(date)
        if (dateExists) {
            Toast.makeText(this, "Weight add Failed", Toast.LENGTH_SHORT).show()
        } else {
            val insertedRowId = graphHelper.insertWeight(weight, date)
            Toast.makeText(this, "Weight add Successful", Toast.LENGTH_SHORT).show()
        }
    }
}
