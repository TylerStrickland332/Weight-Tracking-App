import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import com.example.project3.DatabaseHelper
import com.example.project3.R
import com.example.project3.SignupActivity
import com.example.project3.databinding.ActivityLoginBinding

class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding
    private lateinit var databaseHelper: DatabaseHelper
    private lateinit var loginUsername: String
    private lateinit var loginPassword: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        databaseHelper = DatabaseHelper(this)

        val loginUsernameEditText = findViewById<EditText>(R.id.LoginUsername)
        val loginPasswordEditText = findViewById<EditText>(R.id.LoginPassword)
        val loginButton = findViewById<Button>(R.id.LoginButton)

        loginButton.setOnClickListener{
            loginUsername = loginUsernameEditText.text.toString()
            loginPassword = loginPasswordEditText.text.toString()
            loginDatabase(loginUsername, loginPassword)
        }

        val redirectSignup = findViewById<TextView>(R.id.SignupRedirect)
        redirectSignup.setOnClickListener{
            val intent = Intent(this, SignupActivity::class.java)
            startActivity(intent)
            finish()
        }
    }

    private fun loginDatabase(username: String, password: String){
        val userExists = databaseHelper.readUser(username, password)
        if (userExists){
            Toast.makeText(this, "Login Successful", Toast.LENGTH_SHORT).show()
            val intent = Intent(this, MainActivity3::class.java) // Changed to MainActivity
            startActivity(intent)
            finish()
        } else {
            Toast.makeText(this, "Login Failed", Toast.LENGTH_SHORT).show()
        }
    }
}
