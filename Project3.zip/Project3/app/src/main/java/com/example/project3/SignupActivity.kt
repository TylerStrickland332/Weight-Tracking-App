package com.example.project3

import LoginActivity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import com.example.project3.databinding.ActivitySignupBinding

class SignupActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySignupBinding
    private lateinit var databaseHelper: DatabaseHelper
    private lateinit var signupUsername: String
    private lateinit var signupPassword: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySignupBinding.inflate(layoutInflater)
        setContentView(R.layout.activity_signup)

        databaseHelper = DatabaseHelper(this)

        setContentView(R.layout.activity_signup)

        val signupUsernameEditText = findViewById<EditText>(R.id.SignupUsername)
        val signupPasswordEditText = findViewById<EditText>(R.id.SignupPassword)
        val signupButton = findViewById<Button>(R.id.SignupButton)

        val SignupButton = findViewById<Button>(R.id.SignupButton)
        SignupButton.setOnClickListener{
            signupUsername = signupUsernameEditText.text.toString()
            signupPassword = signupPasswordEditText.text.toString()
            signupDatabase(signupUsername, signupPassword)
        }

        val LoginRedirect = findViewById<TextView>(R.id.LoginRedirect)
        LoginRedirect.setOnClickListener{
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
        }

    }

    private fun signupDatabase(username: String, password: String) {
        val insertedRowId = databaseHelper.insertUser(username, password)
        Toast.makeText(this, "Signup Successful", Toast.LENGTH_SHORT).show()
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
        }
    }
